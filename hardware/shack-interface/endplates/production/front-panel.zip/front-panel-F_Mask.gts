G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-11-10T17:48:03+01:00*
G04 #@! TF.ProjectId,front-panel,66726f6e-742d-4706-916e-656c2e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-11-10 17:48:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,6.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X180262000Y-67320000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X24738000Y-67320000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X180262000Y-23810000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X24738000Y-23810000D03*
G04 #@! TD*
M02*
